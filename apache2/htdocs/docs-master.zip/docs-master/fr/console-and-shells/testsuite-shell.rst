Shell Testsuite
###############

Une fois que vous avez commencé à écrire des
:doc:`Tests </development/testing>`, vous pouvez les lancer en utilisant le
shell testsuite.

Pour plus d'informations sur les utilisations classiques du shell testsuite,
allez voir :ref:`run-tests-from-command-line`.

.. versionchanged:: 2.1
    Le shell ``test``a été ajouté dans 2.1. Le shell ``testsuite`` 2.0 est
    toujours disponible mais la nouvelle syntaxe est préférée.


.. meta::
    :title lang=fr: Testsuite shell
    :keywords lang=fr: shell,ligne de commande
