Contribuer
##########

Il y a un certain nombre de moyens pour contribuer à CakePHP. Les sections
suivantes couvrent les différentes façons avec lesquelles vous pouvez
contribuer à CakePHP:

.. toctree::
    :maxdepth: 1

    contributing/documentation
    contributing/tickets
    contributing/code
    contributing/cakephp-coding-conventions
    contributing/backwards-compatibility
    contributing/cakephp-development-process


.. meta::
    :title lang=fr: Contribuer
    :keywords lang=fr: conventions de programmation,documentation,maxdepth
