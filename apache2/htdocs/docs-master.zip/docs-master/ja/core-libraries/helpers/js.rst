JsHelper
########

.. php:class:: JsHelper(View $view, array $settings = array())

.. note::
    The documentation is not currently supported in ja language for this page.

    Please feel free to send us a pull request on
    `Github <https://github.com/cakephp/docs>`_ or use the **Improve This Doc**
    button to directly propose your changes.

    You can referer to the english version in the select top menu to have
    information about this page's topic.

.. meta::
    :title lang=ja: JsHelper
    :description lang=ja: The Js Helper supports the JavaScript libraries Prototype, jQuery and Mootools and provides methods for manipulating javascript.
    :keywords lang=ja: js helper,javascript,cakephp jquery,cakephp mootools,cakephp prototype,cakephp jquery ui,cakephp scriptaculous,cakephp javascript,javascript engine
