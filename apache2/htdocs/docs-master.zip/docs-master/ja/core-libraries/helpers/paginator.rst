Paginator
#########

.. php:class:: PaginatorHelper(View $view, array $settings = array())

.. note::
    The documentation is not currently supported in ja language for this page.

    Please feel free to send us a pull request on
    `Github <https://github.com/cakephp/docs>`_ or use the **Improve This Doc**
    button to directly propose your changes.

    You can referer to the english version in the select top menu to have
    information about this page's topic.

.. meta::
    :title lang=ja: PaginatorHelper
    :description lang=ja: The Pagination helper is used to output pagination controls such as page numbers and next/previous links.
    :keywords lang=ja: paginator helper,pagination,sort,page number links,pagination in views,prev link,next link,last link,first link,page counter
