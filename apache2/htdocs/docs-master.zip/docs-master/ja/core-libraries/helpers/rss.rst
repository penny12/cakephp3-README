RSS
###

.. php:class:: RssHelper(View $view, array $settings = array())

.. note::
    The documentation is not currently supported in ja language for this page.

    Please feel free to send us a pull request on
    `Github <https://github.com/cakephp/docs>`_ or use the **Improve This Doc**
    button to directly propose your changes.

    You can referer to the english version in the select top menu to have
    information about this page's topic.

.. meta::
    :title lang=ja: RssHelper
    :description lang=ja: The RSS helper makes generating XML for RSS feeds easy.
    :keywords lang=ja: rss helper,rss feed,isrss,rss item,channel data,document data,parse extensions,request handler
