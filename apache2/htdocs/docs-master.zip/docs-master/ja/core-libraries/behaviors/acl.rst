ACL
###

.. php:class:: AclBehavior()

.. note::
    The documentation is not currently supported in ja language for this page.

    Please feel free to send us a pull request on
    `Github <https://github.com/cakephp/docs>`_ or use the **Improve This Doc**
    button to directly propose your changes.

    You can referer to the english version in the select top menu to have
    information about this page's topic.

.. meta::
    :title lang=ja: ACL
    :keywords lang=ja: group node,array type,root node,acl system,acl entry,parent child relationships,model reference,php class,aros,group id,aco,aro,user group,alias,fly
