ビヘイビア
##########

ビヘイビアはモデルに拡張機能を追加します。CakePHP は :php:class:`TreeBehavior` や
:php:class:`ContainableBehavior` など、いくつかの組込みビヘイビアを備えています。

ビヘイビアの作成方法と使い方については学ぶには :doc:`/models/behaviors` を読んでください。

.. toctree::
    :maxdepth: 1

    /core-libraries/behaviors/acl
    /core-libraries/behaviors/containable
    /core-libraries/behaviors/translate
    /core-libraries/behaviors/tree

