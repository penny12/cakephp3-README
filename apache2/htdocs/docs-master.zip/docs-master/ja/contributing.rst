貢献
####

CakePHPの貢献できる方法は数多くあります。
以下のセクションはCakePHPに貢献できる種々の方法をカバーしています。

.. toctree::
    :maxdepth: 1

    contributing/documentation
    contributing/tickets
    contributing/code
    contributing/cakephp-coding-conventions
    contributing/backwards-compatibility
    contributing/cakephp-development-process

.. meta::
    :title lang=ja: 貢献
    :keywords lang=ja: coding conventions,documentation,maxdepth
