テストシェル
############

一度書き始めた :doc:`テスト </development/testing>` はテストシェルで実行可能です。

テストシェルの基本的な使用方法については、
:ref:`run-tests-from-command-line` をご覧ください。

.. versionchanged:: 2.1
    この ``test`` シェルはバージョン2.1より追加されました。バージョン2.0であった ``testsuite`` も利用可能ではありますが、やはり新しい構文が望ましいでしょう。

.. meta::
    :title lang=ja: テストシェル
    :keywords lang=ja: cakephp testing,test shell,testsuite,command line,テストシェル,テストスイート,コマンドライン
