Paginator
#########

.. php:class:: PaginatorHelper(View $view, array $settings = array())

.. note::
    La documentación no es compatible actualmente con el idioma español en esta página.

    Por favor, siéntase libre de enviarnos un pull request en
    `Github <https://github.com/cakephp/docs>`_ o utilizar el botón **Improve this Doc** para proponer directamente los cambios.

    Usted puede hacer referencia a la versión en Inglés en el menú de selección superior
    para obtener información sobre el tema de esta página.

.. meta::
    :title lang=es: PaginatorHelper
    :description lang=es: The Pagination helper is used to output pagination controls such as page numbers and next/previous links.
    :keywords lang=es: paginator helper,pagination,sort,page number links,pagination in views,prev link,next link,last link,first link,page counter
