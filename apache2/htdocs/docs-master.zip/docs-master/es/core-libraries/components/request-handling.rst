Request Handling
################

.. php:class:: RequestHandlerComponent(ComponentCollection $collection, array $settings = array())

.. note::
    La documentación no es compatible actualmente con el idioma español en esta página.

    Por favor, siéntase libre de enviarnos un pull request en
    `Github <https://github.com/cakephp/docs>`_ o utilizar el botón **Improve this Doc** para proponer directamente los cambios.

    Usted puede hacer referencia a la versión en Inglés en el menú de selección superior
    para obtener información sobre el tema de esta página.

.. meta::
    :title lang=es: Request Handling
    :keywords lang=es: handler component,javascript libraries,public components,null returns,model data,request data,content types,file extensions,ajax,meth,content type,array,conjunction,cakephp,insight,php
