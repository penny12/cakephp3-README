Helpers
#######

.. note::
    La documentación no es compatible actualmente con el idioma español en esta página.

    Por favor, siéntase libre de enviarnos un pull request en
    `Github <https://github.com/cakephp/docs>`_ o utilizar el botón **Improve this Doc** para proponer directamente los cambios.

    Usted puede hacer referencia a la versión en Inglés en el menú de selección superior
    para obtener información sobre el tema de esta página.

CakePHP features a number of helpers that aid in view creation. They assist in
creating well-formed markup (including forms), aid in formatting text, times and
numbers, and can even integrate with popular JavaScript libraries. Here is a
summary of the built-in helpers.

Read :doc:`/views/helpers` to learn more about helpers, their API, and how you
can create and use your own helpers.

.. toctree::
    :maxdepth: 1

    /core-libraries/helpers/cache
    /core-libraries/helpers/form
    /core-libraries/helpers/html
    /core-libraries/helpers/js
    /core-libraries/helpers/number
    /core-libraries/helpers/paginator
    /core-libraries/helpers/rss
    /core-libraries/helpers/session
    /core-libraries/helpers/text
    /core-libraries/helpers/time
