General Purpose
###############

.. toctree::
    :maxdepth: 2

    global-constants-and-functions
    ../core-utility-libraries/app
    events
    collections
