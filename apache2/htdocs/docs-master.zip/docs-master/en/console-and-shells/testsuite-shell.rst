Test shell
##########

Once you've started writing :doc:`Tests </development/testing>` you can run them
using the test shell.

For more information on basic usage of the test shell see
:ref:`run-tests-from-command-line`.

.. versionchanged:: 2.1
    The ``test`` shell was added in 2.1. The 2.0 ``testsuite`` shell is still
    available but the new syntax is preferred.


.. meta::
    :title lang=en: Test Shell
    :keywords lang=en: cakephp testing,test shell,testsuite,command line
